#R version 4.4.1 last run by Colleen Apr 15, 2025

#install.packages("tidyverse") #only run once, don't typically need to include in script
#repeat for any other packages you don't have installed already

####----DATA ORGANIZATION----

library(tidyverse) #v2.0.0 
library(janitor) #v2.2.1, for clean_names()

#read in the untidy dataset:
untidy_seminar_data <- read_csv("data/untidy_seminar_data.csv") |> 
#tidy up the column names
  janitor::clean_names() |> 
#replace the "omit"s to NAs
  mutate(across(where(is.character), ~na_if(., "omit"))) |> 
#now that the omits are gone, change the weight columns to all be numeric type
  mutate(across(bud_1_wax_mg:bud_3_dry_weight_mg, ~as.numeric(.x))) |> 
#change date type so that R recognizes format (helpful for graph later)
  mutate(date_collected = as.Date(date_collected,"%b%d-%Y")) |> 
#pivot the weight columns longer, so only one column for each type of weight measurement
  #will need to add a separate column for bud number
  pivot_longer(cols=c(bud_1_wax_mg:bud_3_dry_weight_mg), 
               names_to = c("bud",".value"), names_pattern = "bud_(.)_(.*)") |> 
#filter out rows with NA values for weight (check that this applies to all measurements first!)
  dplyr::filter(!is.na(wax_mg)) |> 
#create column with average weight across all buds for a tree
  group_by(tree, date_collected) |> 
  mutate(avg_wax_per_tree_mg = mean(wax_mg)) |> 
  ungroup()

#read in sample metadata file to join sample codes
sample_metadata <- read_csv("data/sample_metadata.csv") |> 
  janitor::clean_names()

#create updated dataset and join sample metadata
tidier_data <- untidy_seminar_data |> 
  left_join(sample_metadata, 
            by = join_by(tree)) |>  #if the join column names aren't identical, use columnA == columnB
#separate the lims code into different columns
  separate(lims_code, into=c("expt","treatment_code","biol_rep",NA), sep="-", remove=FALSE) |> 
#calculate percent water content, which can be compared to wax - first need everything in same units
  mutate(fresh_weight_mg = fresh_weight_g * 1000) |> 
#perc water content = weight of water/total weight
  mutate(percent_water_content = (fresh_weight_mg-dry_weight_mg)/fresh_weight_mg) |> 
#calculate wax to dry weight ratio
  mutate(wax_per_mg_DW = wax_mg/dry_weight_mg) |> 
#now take the average for each tree (tree = biol rep, bud = tech rep)
  group_by(tree, date_collected) |> 
  mutate(avg_percent_water_per_tree = mean(percent_water_content)) |> 
  mutate(avg_wax_per_mg_DW_per_tree = mean(wax_per_mg_DW)) |> 
  ungroup() |> 
#remove unecessary columns - only want per tree avgs
#-c() will remove the columns you indicate, c() will keep them. ! is another option
  dplyr::select(-c(wax_mg, fresh_weight_mg, fresh_weight_g, 
                   dry_weight_mg, percent_water_content, wax_per_mg_DW)) |> 
#since we only want one average value per tree, remove duplicate lines
  distinct(across(!bud)) #need to exclude lines we know are not distinct

#also want a separate summary of averages by time point & treatment
summarized_data <- tidier_data |> 
  group_by(time_point, treatment) |> 
  summarize(wax_per_mg_DW_treatment_avg = mean(avg_wax_per_mg_DW_per_tree),
            percent_water_treatment_avg = mean(avg_percent_water_per_tree),
            wax_mg_treatment_avg = mean(avg_wax_per_tree_mg))

#export datasets as csv - use this new file for additional analyses so don't need to repeat above steps
write_csv(tidier_data, "data/tidier_seminar_data.csv")


####----SUMMARY TABLE----
library(gt) #v0.11.1

#data is piped directly into table
summarized_data |> 
#replace "_" in column names with spaces so headers look nicer
  rename_with(~gsub("_", " ", .x, fixed=TRUE), ends_with("avg")) |> 
  gt() |> 
#export table - can use .html, .pdf, .docx
  gtsave("tables/summarized_data_table.html")


####----GRAPH----
#make a boxplot of avg wax per mg DW per tree

#load MaizePal package for custom colors
#note that it is not on CRAN, requires install using the devtools package (get on CRAN)
library(MaizePal) #v0.0.1  #devtools::install_github("AndiKur4/MaizePal")

tidier_data |> 
#change time point column to a factor with levels - lets you specify the order
  mutate(time_point = factor(time_point, levels = c("7 dpp", "23 dpp", "43 dpp"))) |> 
#note that you can use pipes going in to ggplot, but it uses + for additional arguments (layers)
  ggplot(aes(y=avg_wax_per_mg_DW_per_tree, x=time_point, fill=treatment))+ 
  geom_boxplot()+ #adds the boxplot layer
  stat_boxplot(geom="errorbar", position = "dodge")+ #adds the errorbars above and below
  theme_bw()+ #removes background and adds border
  theme(legend.position="top", legend.title=element_blank())+ #move the legend to above the plot
  scale_fill_manual(values = maize_pal("GlassGem"))+
  labs(x="Time Point", y="mg Wax per mg Dry Weight")

#export the ggplot, specify file type and dpi - it will save the most recent plot
ggsave("figures/tidier_data_plot.tiff", dpi=600, width = 5, height = 5)


####----CITATIONS----
#Generate bib files for each of your current packages - can be imported to ref manager
library(knitcitations) #v1.0.12. #for write.bibtex function

#first make a list of the packages you used:
pkgs <- c("tidyverse", "janitor", "gt", "MaizePal", "knitcitations") 
#can also use the .packages() function, but it will list all dependencies as well

write.bibtex(do.call('c', lapply(pkgs, citation)), file="tidy_seminar_pkg_citations.bib")
#this will generate a .bib file in the main directory

#best to use the "import" option in zotero (and select .bib file), I find that it doesn't drag & drop well
#includes the package version as a note in the citation in zotero
